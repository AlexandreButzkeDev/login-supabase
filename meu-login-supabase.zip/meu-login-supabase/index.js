import 'dotenv/config'
import { createClient } from '@supabase/supabase-js'
import readline from 'readline'
import fs from 'fs'
import path from 'path'

// Ler credenciais do ambiente (mais seguro que hard-code)
const SUPABASE_URL = process.env.SUPABASE_URL || ''
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || ''

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('ERRO: `SUPABASE_URL` ou `SUPABASE_ANON_KEY` não configurados. Verifique o arquivo .env ou variáveis de ambiente.')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

// Session file helpers
const SESSION_FILE = path.resolve(process.cwd(), '.session.json')

async function restoreSessionIfExists() {
  if (!fs.existsSync(SESSION_FILE)) return false
  try {
    const raw = fs.readFileSync(SESSION_FILE, 'utf8')
    const session = JSON.parse(raw)
    await supabase.auth.setSession({
      access_token: session.access_token,
      refresh_token: session.refresh_token
    })
    return true
  } catch (err) {
    return false
  }
}

function saveSession(session) {
  try {
    const toSave = {
      access_token: session.access_token,
      refresh_token: session.refresh_token
    }
    fs.writeFileSync(SESSION_FILE, JSON.stringify(toSave))
  } catch (err) {
    // ignore
  }
}

function clearSavedSession() {
  try {
    if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE)
  } catch (err) {
    // ignore
  }
}

// Função de registro
async function registrar(email, senha) {
  const { data, error } = await supabase.auth.signUp({
    email: email,
    password: senha
  })

  if (error) {
    console.log("Erro no registro:", error.message)
    return
  }

  console.log("Usuário registrado:", data.user)

  // Criar profile (opcional)
  const { error: profileError } = await supabase
    .from('profiles')
    .insert([{ user_id: data.user.id }])

  if (profileError) {
    console.log("Erro ao criar profile:", profileError.message)
  }
}

// Função de login
async function login(email, senha, interactive = true) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: email,
    password: senha
  })

  if (error) {
    console.log("Erro no login:", error.message)
    return false
  }

  console.log("Login bem-sucedido!")
  console.log("Usuário logado:", data.user)

  // salvar sessão para reutilização
  if (data.session) saveSession(data.session)

  // Buscar profile (opcional)
  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', data.user.id)
    .single()

  console.log("Profile:", profile)

  if (interactive) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
    const ans = await new Promise((res) => rl.question("Pressione 'x' para deslogar agora, ou Enter para continuar: ", (a) => { rl.close(); res(a.trim()) }))
    if (ans.toLowerCase() === 'x') {
      await supabase.auth.signOut()
      clearSavedSession()
      console.log('Deslogado.')
    }
  }

  return true
}

// Testando: criar usuário de teste e tentar login
async function criarUsuarioETestar(email, senha) {
  console.log('Criando usuário de teste:', email)
  const reg = await registrar(email, senha)

  if (reg) {
    console.log('Tentando login com usuário de teste...')
    await login(email, senha)
  } else {
    console.log('Registro falhou; não tentando login.')
  }
}

function questionAsync(rl, q) {
  return new Promise((resolve) => rl.question(q, (ans) => resolve(ans.trim())))
}

async function interactiveCli() {
  // modo não interativo para testes automatizados
  if (process.env.NONINTERACTIVE === '1') {
    const choice = process.env.TEST_CHOICE || '2'
    const email = process.env.TEST_EMAIL || 'teste@teste.com'
    const senha = process.env.TEST_PASSWORD || '12345678'
    if (choice === '1') {
      await login(email, senha)
    } else {
      await criarUsuarioETestar(email, senha)
    }
    return
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  try {
    const choice = await questionAsync(rl, 'Digite 1 para usuário cadastrado, 2 para usuário não cadastrado: ')
    if (choice === '1') {
      const email = await questionAsync(rl, 'Email: ')
      const senha = await questionAsync(rl, 'Senha: ')
      await login(email, senha)
    } else if (choice === '2') {
      const email = await questionAsync(rl, 'Email para cadastro: ')
      const senha = await questionAsync(rl, 'Senha para cadastro: ')
      const ok = await registrar(email, senha)
      if (ok) console.log('Cadastro realizado com sucesso — agora tentando login...')
      else console.log('Falha no cadastro.')
      await login(email, senha)
    } else {
      console.log('Opção inválida.')
    }
  } finally {
    rl.close()
  }
}

// entrypoint
// on start: restore existing session and offer logout
;(async () => {
  const restored = await restoreSessionIfExists()
  if (restored) {
    try {
      const { data: { user }, error } = await supabase.auth.getUser()
      if (!error && user) {
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
        try {
          const choice = await questionAsync(rl, `Sessão encontrada para ${user.email}.\n1) Continuar com essa sessão\n2) Deslogar e reiniciar\n3) Entrar com outro usuário\n4) Cadastrar novo usuário\nDigite 1/2/3/4: `)
          if (choice === '1') {
            console.log('Continuando com sessão existente.')
            const { data: profile } = await supabase.from('profiles').select('*').eq('user_id', user.id).single()
            console.log('Profile:', profile)
            return
          }
          if (choice === '2') {
            await supabase.auth.signOut()
            clearSavedSession()
            console.log('Sessão encerrada. Reiniciando fluxo...')
            await interactiveCli()
            return
          }
          if (choice === '3') {
            const email = await questionAsync(rl, 'Email: ')
            const senha = await questionAsync(rl, 'Senha: ')
            await login(email, senha)
            return
          }
          if (choice === '4') {
            const email = await questionAsync(rl, 'Email para cadastro: ')
            const senha = await questionAsync(rl, 'Senha para cadastro: ')
            const ok = await registrar(email, senha)
            if (ok) console.log('Cadastro realizado com sucesso — agora tentando login...')
            else console.log('Falha no cadastro.')
            await login(email, senha)
            return
          }
          console.log('Opção inválida. Reiniciando fluxo interativo...')
          await interactiveCli()
          return
        } finally {
          rl.close()
        }
      }
    } catch (err) {
      // ignore and continue to interactive
    }
  }

  interactiveCli().catch((err) => {
    console.error('Erro inesperado:', err)
    process.exit(1)
  })
})()
